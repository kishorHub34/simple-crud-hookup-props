import React, { useState } from 'react';
import AddBooksForm from "./components/addform";
import EditUserForm from "./components/editform";
import ValueTable from "./components/valuetable";
import { IBaseBook, IBook } from "./components/interface";
const defaultBooks: Array<IBook> = [
  {
    bookname: "a",
    authur: "aa",
    id: 1,
    price: 44,
  },
  {
    bookname: "a",
    authur: "aa",
    id: 2,
    price: 44
  }

];
const initCurrentBook: IBook = { bookname: "", authur: "", id: 0, price:0 , };

function App() {
  const [books, setbooks] = useState(defaultBooks);
  const [editbook, seteditbook] = useState(initCurrentBook);
  const [editing, setedit] = useState(false);
  const onAddBook = (newBook: IBaseBook) => {
    const id = books.length + 1;
    setbooks([...books, { ...newBook, id }]);
  };
  const onCurrentBooks = (books: IBook) => {
    seteditbook(books);
    setedit(true);
  };
  const onUpdate = (id: number, newBook: IBook) => {
    setedit(false);
    setbooks(books.map(i => (i.id === id ? newBook : i)));
  };
  const onDelete = (onCurrentBooks: IBook) => {
    setbooks(books.filter(i => i.id !== onCurrentBooks.id));


  };



  return (
    <div>
      <h1>CRUD OPERATION ON BOOK STORE</h1>

      {editing ? (<EditUserForm book={editbook} setedit={setedit} onUpdate={onUpdate} />) : (<AddBooksForm onAddBooks={onAddBook} />
      )}

      <ValueTable books={books}
        onEdit={onCurrentBooks} onDelete={onDelete}/>
        
    </div>

  );
}

export default App;
