import React,{useState,useEffect} from "react";
import { IBook } from "./interface";
interface iprops{
    book:IBook;
    onUpdate:(id:number,books:IBook)=>void;
    setedit:(bool:boolean)=>void;
}
export default function EditUserForm(props:iprops){
    const [book,setbook]=useState(props.book);
useEffect(()=>setbook(props.book),[props]);
const onformsubmit=(e:React.FormEvent<HTMLFormElement>)=>{
    e.preventDefault();
    if(!book.bookname || !book.authur){
        return false;

    }
    props.onUpdate(book.id,book);


};
const inputchange=(e:React.ChangeEvent<HTMLInputElement>)=>{
    const {name,value}=e.target;
    setbook({...book,[name]:value});
};
return(
    <div><h1>Edit the values</h1>
    <form  onSubmit={onformsubmit}>
        <div>
            <label>BookName</label>
            <input type="text" onChange={inputchange} placeholder="enter the book name" name="bookname" value={book.bookname} />
        </div>
        <div>
            <label>author</label>
            <input type="text" onChange={inputchange} placeholder="enter the author name" name="authur" value={book.authur} />
        </div>
        <div>
            <label>price</label>
            <input type="text" placeholder="enter the book price" name="price" value={book.price} onChange={inputchange} />
        </div>
        <div>
            <button>Update</button>
            <button onClick={()=>props.setedit(false)}> cancel</button>
        </div>
    </form>
    </div>
)

}