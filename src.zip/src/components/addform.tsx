import React, { useState } from "react";
import { IBaseBook } from "./interface";
interface iprops {
    onAddBooks: (books: IBaseBook) => void;
}
const initBooks = {
    bookname: "",
    authur: "",
    price:0,
};
const AddBooksForm: React.FC<iprops> = (props) => {
    const [formvalue, setformvalue] = useState(initBooks);
    const onformsubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        props.onAddBooks(formvalue);
        setformvalue(initBooks);


    };
    const inputchange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setformvalue({ ...formvalue, [name]: value });
    };
    return (
        <div>
            <h1>AddBooks Store values</h1>
            <form onSubmit={onformsubmit}>
                <div>
                    <label>BookName:</label>
                    <input type="text" placeholder="enter the book name"
                        name="bookname"
                        value={formvalue.bookname
                        } onChange={inputchange} />
                </div>
                <div>
                    <label>Author:</label>
    <input type="text" placeholder="enter the authur name" name="authur" value={formvalue.authur} onChange={inputchange} />

                </div>
                <div>
                    <label>
                        Price:
                    </label>
                    <input type="text" placeholder="enter the price of the book" name="price" value={formvalue.price} onChange={inputchange
                }/>

                </div>
                <div>
                    <button>Add New Book</button>
                </div>

            </form>

        </div>
    );


};
export default AddBooksForm;