import React from "react";
import { IBook } from "./interface";
interface iprops {
    books: Array<IBook>;
    onEdit: (book: IBook) => void;
    onDelete:(book:IBook)=>void;

}
const ValueTable: React.FC<iprops> = (props) => {
    return (
        <div><h1>view Books</h1>
            <table>
                <thead><tr><th>ID</th><th>Book Name</th><th>Author</th><th>Price</th></tr></thead>
                <tbody>
                    {props.books.length > 0 ? (
                        props.books.map((i) => (
                            <tr key={i.id}>
                                 <td>{i?.id}</td>
                               
                                <td>{i?.bookname}</td>
                                
                                <td>{i["authur"]}</td>
                                <td>{i["price"]}</td>
                                <button onClick={()=>props.onEdit(i)}>Edit</button> 
                                <button onClick={()=>props.onDelete(i)}>Delete</button>                  </tr>
                        ))
                    ):(
                        <tr><td colSpan={3}>no books available</td></tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
export default ValueTable;