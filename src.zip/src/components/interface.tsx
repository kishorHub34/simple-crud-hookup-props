export interface IBaseBook{
    bookname:string;
    authur:string;
    price:number;
}
export interface IBook extends IBaseBook{
    id:number;
}